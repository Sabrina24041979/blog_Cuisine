<h2>
    Source view
</h2>
<p>
    This screen shows translation files in their <strong>raw</strong> form.
    It's read-only because the file syntax is very easy to get wrong.
    Click the "Editor" tab to make changes safely.
</p>